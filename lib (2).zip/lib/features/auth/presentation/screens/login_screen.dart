import 'package:faculity_app2/core/services/service_locator.dart';
import 'package:faculity_app2/features/admin/presentation/screens/admin_dashboard_screen.dart';
import 'package:faculity_app2/features/auth/presentation/cubit/auth_cubit.dart';
import 'package:faculity_app2/features/auth/widgets/login_header.dart';
import 'package:faculity_app2/features/auth/widgets/role_selector_widget.dart';
import 'package:faculity_app2/features/auth/widgets/sign_up_prompt.dart';
import 'package:faculity_app2/features/exams/presentation/screens/manage_exams_screen.dart';
import 'package:faculity_app2/features/head_of_exams/presentation/screens/exams_for_publishing_screen.dart';
import 'package:faculity_app2/features/main_screen/presentation/screens/student_main_screen.dart';
import 'package:faculity_app2/features/personnel_office/presentation/screens/personnel_dashboard_screen.dart';
import 'package:faculity_app2/features/staff/presentation/screens/staff_list_screen.dart';
import 'package:faculity_app2/features/student_affairs/presentation/screens/student_affairs_dashboard_screen.dart';
import 'package:faculity_app2/features/teachers/presentation/screens/teacher_list_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../domain/entities/user.dart';
import '../cubit/login_cubit.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // توفير الـ Cubit في الأعلى
    return BlocProvider(
      create: (context) => sl<LoginCubit>(),
      // بناء الواجهة الفعلية باستخدام context جديد
      child: const _LoginView(),
    );
  }
}

// ===============================================
//  ويدجت عرض الواجهة
// ===============================================
class _LoginView extends StatefulWidget {
  const _LoginView();

  @override
  State<_LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<_LoginView> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _extraFieldController = TextEditingController();
  String _selectedRole = 'student';

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _extraFieldController.dispose();
    super.dispose();
  }

  void _onRoleChanged(String newRole) {
    if (_selectedRole != newRole) {
      _extraFieldController.clear();
      setState(() {
        _selectedRole = newRole;
      });
    }
  }

  void _login() {
    if (_formKey.currentState!.validate()) {
      // تحديد الدور الذي سيتم إرساله للـ API
      String apiRole = _selectedRole;
      // كل الأدوار الأخرى (غير الطالب) تسجل الدخول كـ "admin" للـ API
      if (_selectedRole != 'student') {
        apiRole = 'admin';
      }

      final extraFieldConfig = _extraFieldConfig[_selectedRole];
      final Map<String, dynamic> data = {
        'role': apiRole, // <-- استخدام الدور المحدد للـ API
        'email': _emailController.text.trim(),
        'password': _passwordController.text.trim(),
      };

      if (extraFieldConfig != null) {
        data[extraFieldConfig['name']] = _extraFieldController.text.trim();
      }

      // استدعاء دالة تسجيل الدخول من الـ Cubit
      context.read<LoginCubit>().login(data: data);
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<LoginCubit, LoginState>(
      listener: (context, state) {
        if (state is LoginSuccess) {
          // إخبار الـ AuthCubit بنجاح تسجيل الدخول
          context.read<AuthCubit>().loggedIn(state.user);

          // **منطق التوجيه بناءً على الدور المختار في الواجهة**
          switch (_selectedRole) {
            case 'admin':
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => AdminDashboardScreen(user: state.user),
                ),
              );
              break;
            case 'student':
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => StudentMainScreen(user: state.user),
                ),
              );
              break;
            case 'teacher':
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const TeacherListScreen()),
              );
              break;
            case 'staff':
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const StaffListScreen()),
              );
              break;
            case 'dean':
              // مؤقتًا، العميد يوجه إلى شاشة الأدمن الرئيسية
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => AdminDashboardScreen(user: state.user),
                ),
              );
              break;
            case 'studentAffairs':
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => const StudentAffairsDashboardScreen(),
                ),
              );
              break;
            case 'personnel_office':
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => const PersonnelDashboardScreen(),
                ),
              );
              break;
            case 'exams':
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const ManageExamsScreen()),
              );
              break;
            case 'head_of_exam':
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => const ExamsForPublishingScreen(),
                ),
              );
              break;
            default:
              // في حال وجود دور غير معروف، يتم توجيهه للشاشة الرئيسية للطالب
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => StudentMainScreen(user: state.user),
                ),
              );
          }
        } else if (state is LoginFailure) {
          // عرض رسالة خطأ في حالة الفشل
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.error), backgroundColor: Colors.red),
          );
        }
      },
      builder: (context, state) {
        final isLoading = state is LoginLoading;
        final extraFieldConfig = _extraFieldConfig[_selectedRole];

        return Scaffold(
          body: AbsorbPointer(
            absorbing: isLoading,
            child: SafeArea(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Colors.blue.shade200, Colors.blue.shade500],
                  ),
                ),
                child: Center(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 24.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const LoginHeader(),
                        const SizedBox(height: 40),
                        Container(
                          padding: const EdgeInsets.all(24.0),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 20,
                                offset: const Offset(0, 10),
                              ),
                            ],
                          ),
                          child: Form(
                            key: _formKey,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                RoleSelectorWidget(
                                  onRoleSelected: _onRoleChanged,
                                ),
                                const SizedBox(height: 20),
                                TextFormField(
                                  controller: _emailController,
                                  keyboardType: TextInputType.emailAddress,
                                  decoration: const InputDecoration(
                                    hintText: 'البريد الإلكتروني',
                                    prefixIcon: Icon(Icons.email_outlined),
                                  ),
                                  validator: (value) {
                                    if (value == null ||
                                        value.isEmpty ||
                                        !value.contains('@')) {
                                      return 'الرجاء إدخال بريد إلكتروني صالح';
                                    }
                                    return null;
                                  },
                                ),
                                const SizedBox(height: 16),
                                AnimatedSwitcher(
                                  duration: const Duration(milliseconds: 300),
                                  child:
                                      extraFieldConfig == null
                                          ? const SizedBox.shrink()
                                          : Padding(
                                            key: ValueKey(_selectedRole),
                                            padding: const EdgeInsets.only(
                                              bottom: 16.0,
                                            ),
                                            child: TextFormField(
                                              controller: _extraFieldController,
                                              decoration: InputDecoration(
                                                hintText:
                                                    extraFieldConfig['label'],
                                                prefixIcon: Icon(
                                                  extraFieldConfig['icon'],
                                                ),
                                              ),
                                              validator: (value) {
                                                if (value == null ||
                                                    value.isEmpty) {
                                                  return 'الرجاء إدخال ${extraFieldConfig['label']}';
                                                }
                                                return null;
                                              },
                                            ),
                                          ),
                                ),
                                TextFormField(
                                  controller: _passwordController,
                                  obscureText: true,
                                  decoration: const InputDecoration(
                                    hintText: 'كلمة المرور',
                                    prefixIcon: Icon(Icons.lock_outline),
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'الرجاء إدخال كلمة المرور';
                                    }
                                    return null;
                                  },
                                ),
                                const SizedBox(height: 24),
                                ElevatedButton(
                                  onPressed: isLoading ? null : _login,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.blue,
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 16,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    textStyle: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Cairo',
                                    ),
                                  ),
                                  child:
                                      isLoading
                                          ? const SizedBox(
                                            height: 24,
                                            width: 24,
                                            child: CircularProgressIndicator(
                                              color: Colors.white,
                                              strokeWidth: 3,
                                            ),
                                          )
                                          : const Text('تسجيل الدخول'),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        const SignUpPrompt(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

// هذه البيانات يجب أن تكون خارج أي كلاس
const Map<String, Map<String, dynamic>?> _extraFieldConfig = {
  'student': {
    'name': 'university_id',
    'label': 'الرقم الجامعي',
    'icon': Icons.school_outlined,
  },
  'teacher': {
    'name': 'employee_id',
    'label': 'الرقم الوظيفي',
    'icon': Icons.badge_outlined,
  },
  'staff': null,
  'admin': null,
  'dean': null,
  'studentAffairs': null,
  'personnel_office': null,
  'exams': null,
  'head_of_exam': null,
};
