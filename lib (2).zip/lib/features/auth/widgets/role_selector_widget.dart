// lib/features/auth/widgets/role_selector_widget.dart

import 'package:flutter/material.dart';

class RoleSelectorWidget extends StatefulWidget {
  final Function(String) onRoleSelected;

  const RoleSelectorWidget({super.key, required this.onRoleSelected});

  @override
  State<RoleSelectorWidget> createState() => _RoleSelectorWidgetState();
}

class _RoleSelectorWidgetState extends State<RoleSelectorWidget> {
  int _selectedIndex = 0;
  // **تمت إضافة الأدوار الجديدة هنا**
  final List<Map<String, dynamic>> _roles = [
    {'name': 'طالب', 'value': 'student', 'icon': Icons.person_outline},
    {'name': 'دكتور', 'value': 'teacher', 'icon': Icons.school_outlined},
    {'name': 'موظف', 'value': 'staff', 'icon': Icons.work_outline},
    {
      'name': 'مسؤول',
      'value': 'admin',
      'icon': Icons.admin_panel_settings_outlined,
    },
    {'name': 'عميد', 'value': 'dean', 'icon': Icons.star_outline},
    {
      'name': 'شؤون طلاب',
      'value': 'studentAffairs',
      'icon': Icons.groups_outlined,
    },
    {
      'name': 'ذاتية',
      'value': 'personnel_office',
      'icon': Icons.badge_outlined,
    },
    {'name': 'امتحانات', 'value': 'exams', 'icon': Icons.edit_note_outlined},
    {
      'name': 'رئيس امتحانات',
      'value': 'head_of_exam',
      'icon': Icons.grading_outlined,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'تسجيل الدخول كـ:',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black54,
          ),
        ),
        const SizedBox(height: 10),
        // استخدام GridView لجعل الواجهة أفضل مع الأدوار الكثيرة
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: 0.9,
          ),
          itemCount: _roles.length,
          itemBuilder: (context, index) {
            bool isSelected = _selectedIndex == index;
            return GestureDetector(
              onTap: () {
                setState(() {
                  _selectedIndex = index;
                  widget.onRoleSelected(_roles[index]['value']);
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                decoration: BoxDecoration(
                  color:
                      isSelected ? Colors.blue.shade50 : Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected ? Colors.blue : Colors.grey.shade300,
                    width: isSelected ? 2 : 1,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _roles[index]['icon'],
                      color: isSelected ? Colors.blue : Colors.grey.shade600,
                      size: 28,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _roles[index]['name'],
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight:
                            isSelected ? FontWeight.bold : FontWeight.normal,
                        color: isSelected ? Colors.blue : Colors.grey.shade800,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
