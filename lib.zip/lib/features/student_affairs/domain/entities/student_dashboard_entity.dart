import 'package:equatable/equatable.dart';
import 'package:faculity_app2/features/student/data/models/student_model.dart';

class StudentDashboardEntity extends Equatable {
  final Map<String, List<StudentModel>> studentsByYear;

  const StudentDashboardEntity({required this.studentsByYear});

  @override
  List<Object?> get props => [studentsByYear];
}
