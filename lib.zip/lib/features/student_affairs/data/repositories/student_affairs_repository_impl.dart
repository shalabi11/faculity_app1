import 'dart:io';

import 'package:faculity_app2/core/errors/failures.dart';
import 'package:faculity_app2/core/platform/network_info.dart';
import 'package:faculity_app2/features/student/data/models/student_model.dart';
// افترض وجود هذا المودل
import 'package:dartz/dartz.dart';
import 'package:faculity_app2/features/student_affairs/data/datasource/student_affairs_remote_data_source.dart';
import 'package:faculity_app2/features/student_affairs/data/repositories/student_affairs_repository.dart';
import 'package:faculity_app2/features/student_affairs/domain/entities/student_dashboard_entity.dart';

class StudentAffairsRepositoryImpl implements StudentAffairsRepository {
  final StudentAffairsRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  StudentAffairsRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, StudentDashboardEntity>>
  getStudentDashboardData() async {
    if (await networkInfo.isConnected) {
      try {
        final allStudents = await remoteDataSource.getAllStudents();
        final dashboardData = _processStudentData(allStudents);
        return Right(dashboardData);
      } catch (e) {
        return Left(ServerFailure());
      }
    } else {
      return Left(OfflineFailure());
    }
  }

  StudentDashboardEntity _processStudentData(List<StudentModel> students) {
    final Map<String, List<StudentModel>> studentsByYear = {
      'الأولى': [],
      'الثانية': [],
      'الثالثة': [],
      'الرابعة': [],
      'الخامسة': [],
    };

    for (var student in students) {
      // ملاحظة: تأكد من أن مودل الطالب يحتوي على حقل 'year'
      if (studentsByYear.containsKey(student.year)) {
        studentsByYear[student.year]!.add(student);
      }
    }
    return StudentDashboardEntity(studentsByYear: studentsByYear);
  }

  @override
  Future<Either<Failure, Unit>> addStudent(StudentModel student, File? image) {
    // TODO: implement addStudent
    throw UnimplementedError();
  }
}
