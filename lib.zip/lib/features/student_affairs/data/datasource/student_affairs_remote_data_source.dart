import 'dart:io';
import 'package:dio/dio.dart';
import 'package:faculity_app2/core/utils/constant.dart'; // تأكد من صحة المسار
import 'package:faculity_app2/core/errors/exceptions.dart'; // تأكد من صحة المسار
import 'package:faculity_app2/features/student/data/models/student_model.dart'; // تأكد من صحة المسار

abstract class StudentAffairsRemoteDataSource {
  Future<List<StudentModel>> getAllStudents();
  Future<void> addStudent(StudentModel student, File? image);
}

class StudentAffairsRemoteDataSourceImpl
    implements StudentAffairsRemoteDataSource {
  final Dio dio;

  StudentAffairsRemoteDataSourceImpl({required this.dio});

  Future<Options> _getAuthHeaders() async {
    // --- استخدام التوكن التجريبي ---
    const String manualToken =
        "10|2EiXIR1wWLQmbJOkqAhOhQ8oK9yRYEqV5ReKLERd4067ee2c";

    return Options(
      headers: {
        'Authorization': 'Bearer $manualToken',
        'Accept': 'application/json',
      },
    );
  }

  @override
  Future<List<StudentModel>> getAllStudents() async {
    try {
      final response = await dio.get(
        '$baseUrl/api/students',
        options: await _getAuthHeaders(),
      );
      final List<dynamic> jsonList = response.data;
      return jsonList.map((json) => StudentModel.fromJson(json)).toList();
    } on DioException catch (e) {
      print('DioException in getAllStudents: ${e.response?.data}');
      throw ServerException(message: 'فشل الاتصال بالخادم');
    }
  }

  @override
  Future<void> addStudent(StudentModel student, File? image) async {
    try {
      final Map<String, dynamic> studentData = {
        'university_id': student.universityId,
        'full_name': student.fullName,
        'mother_name': student.motherName,
        'birth_date': student.birthDate,
        'birth_place': student.birthPlace,
        'department': student.department,
        'year': student.year,
        'high_school_gpa': student.highSchoolGpa.toString(),
      };

      if (image != null) {
        studentData['profile_image'] = await MultipartFile.fromFile(
          image.path,
          filename: image.path.split('/').last,
        );
      }

      final formData = FormData.fromMap(studentData);

      await dio.post(
        '$baseUrl/api/students',
        data: formData,
        options: await _getAuthHeaders(),
      );
    } on DioException catch (e) {
      print('DioException in addStudent: ${e.response?.data}');
      throw ServerException(message: 'فشل في إضافة الطالب');
    }
  }
}
