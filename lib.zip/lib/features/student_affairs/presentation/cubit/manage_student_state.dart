part of 'manage_student_cubit.dart';

abstract class ManageStudentState extends Equatable {
  const ManageStudentState();

  @override
  List<Object> get props => [];
}

class ManageStudentInitial extends ManageStudentState {}

class ManageStudentLoading extends ManageStudentState {}

class ManageStudentSuccess extends ManageStudentState {}

class ManageStudentError extends ManageStudentState {
  final String message;
  const ManageStudentError({required this.message});

  @override
  List<Object> get props => [message];
}
