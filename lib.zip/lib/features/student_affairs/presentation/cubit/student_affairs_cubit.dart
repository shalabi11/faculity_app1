import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:faculity_app2/features/student_affairs/domain/entities/usecases/get_student_dashboard_data.dart';
import '../../../../core/usecases/usecase.dart';
import '../../domain/entities/student_dashboard_entity.dart';

part 'student_affairs_state.dart';

class StudentAffairsCubit extends Cubit<StudentAffairsState> {
  final GetStudentDashboardData getStudentDashboardData;

  StudentAffairsCubit({required this.getStudentDashboardData})
    : super(StudentAffairsInitial());

  Future<void> fetchDashboardData() async {
    emit(StudentAffairsLoading());
    final failureOrData = await getStudentDashboardData(NoParams());
    failureOrData.fold(
      (failure) =>
          emit(const StudentAffairsError(message: 'فشل في جلب البيانات')),
      (data) => emit(StudentAffairsLoaded(dashboardData: data)),
    );
  }
}
