// lib/features/student/presentation/cubit/manage_student_state.dart

part of 'manage_student_cubit.dart';

abstract class ManageStudentState {
  String? message;
}

class ManageStudentInitial extends ManageStudentState {}

class ManageStudentLoading extends ManageStudentState {}

class ManageStudentSuccess extends ManageStudentState {
  final String message;
  ManageStudentSuccess(this.message);
}

class ManageStudentFailure extends ManageStudentState {
  final String message;
  ManageStudentFailure(this.message);
}
