class ExamResult {
  final int id;
  final String courseName;
  final double score;

  ExamResult({required this.id, required this.courseName, required this.score});
}
