// lib/core/services/service_locator.dart

import 'package:dio/dio.dart';
import 'package:faculity_app2/features/student_affairs/data/repositories/student_affairs_repository.dart';
import 'package:faculity_app2/features/student_affairs/domain/entities/usecases/add_student.dart';
import 'package:faculity_app2/features/student_affairs/domain/entities/usecases/get_student_dashboard_data.dart';
import 'package:get_it/get_it.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';

// Core
import 'package:faculity_app2/core/platform/network_info.dart';
import 'package:faculity_app2/core/theme/cubit/theme_cubit.dart';

// --- استيراد ملفات "شؤون الطلاب" (الميزة الجديدة) ---
import 'package:faculity_app2/features/student_affairs/data/datasource/student_affairs_remote_data_source.dart';
import 'package:faculity_app2/features/student_affairs/data/repositories/student_affairs_repository_impl.dart';
import 'package:faculity_app2/features/student_affairs/presentation/cubit/student_affairs_cubit.dart';
import 'package:faculity_app2/features/student_affairs/presentation/cubit/manage_student_cubit.dart'
    as affairs; // <-- استخدام alias لتجنب التعارض

// --- استيراد ملفات الطلاب (القديمة للعرض فقط) ---
import 'package:faculity_app2/features/student/data/datasource/student_remote_data_source.dart';
import 'package:faculity_app2/features/student/domain/repositories/student_repository.dart';
import 'package:faculity_app2/features/student/domain/repositories/student_repository_impl.dart';
import 'package:faculity_app2/features/student/presentation/cubit/student_cubit.dart';

// ... (باقي استدعاءات الـ import الأخرى)

final sl = GetIt.instance;

Future<void> setupServiceLocator() async {
  // =====================
  //  External & Core
  // =====================
  final sharedPreferences = await SharedPreferences.getInstance();
  sl.registerLazySingleton(() => sharedPreferences);
  sl.registerLazySingleton(() => Dio());
  sl.registerLazySingleton(() => const FlutterSecureStorage());
  sl.registerLazySingleton(() => InternetConnectionChecker.createInstance());
  sl.registerLazySingleton<NetworkInfo>(() => NetworkInfoImpl(sl()));
  sl.registerFactory<ThemeCubit>(() => ThemeCubit(sharedPreferences: sl()));

  // =======================================================
  //  Features Registration
  // =======================================================

  // --- 🌟 ميزة شؤون الطلاب (القسم الجديد والأساسي) 🌟 ---
  // Cubits (الواجهة)
  sl.registerFactory(() => StudentAffairsCubit(getStudentDashboardData: sl()));
  sl.registerFactory<affairs.ManageStudentCubit>(
    () => affairs.ManageStudentCubit(addStudentUseCase: sl()),
  );

  // sl.registerFactory(() => affairs.ManageStudentCubit(addStudentUseCase: sl()));
  // UseCases (المنطق)
  sl.registerLazySingleton(() => GetStudentDashboardData(sl()));
  sl.registerLazySingleton(() => AddStudent(sl()));
  // Repository (مستودع البيانات)
  sl.registerLazySingleton<StudentAffairsRepository>(
    () =>
        StudentAffairsRepositoryImpl(remoteDataSource: sl(), networkInfo: sl()),
  );
  // DataSource (مصدر البيانات)
  sl.registerLazySingleton<StudentAffairsRemoteDataSource>(
    () => StudentAffairsRemoteDataSourceImpl(dio: sl()),
  );
  // --- نهاية قسم شؤون الطلاب ---

  // --- Student Feature (القديم - يستخدم الآن لعرض القوائم فقط) ---
  sl.registerLazySingleton<StudentRemoteDataSource>(
    () => StudentRemoteDataSourceImpl(dio: sl(), secureStorage: sl()),
  );
  sl.registerLazySingleton<StudentRepository>(
    () => StudentRepositoryImpl(remoteDataSource: sl()),
  );
  sl.registerFactory<StudentCubit>(() => StudentCubit(studentRepository: sl()));

  // تم تعطيل السطر المسبب للتعارض، لأن النسخة الجديدة هي المسؤولة عن الإدارة
  // sl.registerFactory<ManageStudentCubit>(() => ManageStudentCubit(studentRepository: sl()));

  // --- Auth Feature ---
  // ... (الكود الخاص بالمصادقة يبقى كما هو)

  // ... (جميع الميزات الأخرى تبقى كما هي)
}
