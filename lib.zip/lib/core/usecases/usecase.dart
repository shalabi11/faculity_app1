import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../errors/failures.dart';

// الفئة الأساسية لجميع الـ Use Cases
// Type: هو نوع البيانات التي ستعود في حال النجاح
// Params: هو نوع البيانات التي سيتم تمريرها للـ Use Case
abstract class UseCase<Type, Params> {
  Future<Either<Failure, Type>> call(Params params);
}

// فئة مساعدة في حال كان الـ Use Case لا يحتاج إلى أي متغيرات
class NoParams extends Equatable {
  @override
  List<Object> get props => [];
}
