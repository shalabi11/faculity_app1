import 'package:equatable/equatable.dart';

// الفئة الأساسية لجميع أنواع الفشل
abstract class Failure extends Equatable {
  const Failure([List properties = const <dynamic>[]]);

  @override
  List<Object> get props => [];
}

// ---- أنواع الفشل العامة ----

// يحدث عند وجود مشكلة في الخادم (Server)
class ServerFailure extends Failure {}

// يحدث عند عدم وجود اتصال بالإنترنت
class OfflineFailure extends Failure {}

// يحدث عند وجود مشكلة في البيانات المخزنة محلياً (Cache)
class EmptyCacheFailure extends Failure {}
