// lib/features/student_affairs/presentation/screens/student_affairs_dashboard_screen.dart

import 'package:faculity_app2/core/services/service_locator.dart' as di;
import 'package:faculity_app2/features/student/data/models/student_model.dart';
import 'package:faculity_app2/features/student_affairs/presentation/cubit/manage_student_cubit.dart';
import 'package:faculity_app2/features/student_affairs/presentation/cubit/student_affairs_cubit.dart';
import 'package:faculity_app2/features/student_affairs/presentation/screens/add_student_screen.dart';
import 'package:faculity_app2/features/student_affairs/presentation/screens/students_by_year_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class StudentAffairsDashboardScreen extends StatelessWidget {
  const StudentAffairsDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // 1. توفير الـ Cubit للشاشة بالكامل
    return BlocProvider(
      create: (context) => di.sl<StudentAffairsCubit>()..fetchStudents(),
      child: const _StudentAffairsDashboardView(),
    );
  }
}

// 2. بناء الواجهة في ويدجت منفصل لضمان الوصول الصحيح للـ Cubit
class _StudentAffairsDashboardView extends StatelessWidget {
  const _StudentAffairsDashboardView();

  @override
  Widget build(BuildContext context) {
    final colors = [
      Colors.blue.shade300,
      Colors.green.shade300,
      Colors.orange.shade300,
      Colors.purple.shade300,
      Colors.red.shade300,
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'لوحة تحكم شؤون الطلاب',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.teal.shade700,
        elevation: 4,
      ),
      body: BlocBuilder<StudentAffairsCubit, StudentAffairsState>(
        builder: (context, state) {
          if (state is StudentAffairsLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is StudentAffairsLoaded) {
            // تجميع الطلاب حسب السنة
            final Map<String, List<StudentModel>> studentsByYear = {};
            for (var student in state.students) {
              (studentsByYear[student.year] ??= []).add(
                student as StudentModel,
              );
            }
            final years = studentsByYear.keys.toList();

            return GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 1.2,
              ),
              itemCount: years.length,
              itemBuilder: (context, index) {
                final year = years[index];
                final students = studentsByYear[year] ?? [];
                return _buildYearCard(
                  context,
                  year,
                  students,
                  colors[index % colors.length],
                );
              },
            );
          } else if (state is StudentAffairsError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(state.message, style: const TextStyle(fontSize: 16)),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () {
                      context.read<StudentAffairsCubit>().fetchStudents();
                    },
                    child: const Text('إعادة المحاولة'),
                  ),
                ],
              ),
            );
          }
          return const Center(child: Text('يرجى تحديث البيانات'));
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
              builder:
                  (_) => BlocProvider(
                    create: (context) => di.sl<ManageStudentCubit>(),
                    child: const AddStudentScreen(),
                  ),
            ),
          );

          if (result == true && context.mounted) {
            context.read<StudentAffairsCubit>().fetchStudents();
          }
        },
        backgroundColor: Colors.teal.shade800,
        tooltip: 'إضافة طالب جديد',
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildYearCard(
    BuildContext context,
    String year,
    List<StudentModel> students,
    Color color,
  ) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder:
                (_) => StudentsByYearScreen(year: year, students: students),
          ),
        );
      },
      borderRadius: BorderRadius.circular(20),
      child: Card(
        elevation: 6,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        color: color,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'السنة $year',
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    students.length.toString(),
                    style: const TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Icon(Icons.person, color: Colors.white, size: 30),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
