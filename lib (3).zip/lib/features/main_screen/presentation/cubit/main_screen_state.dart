part of 'main_screen_cubit.dart';

class MainScreenState {
  final int selectedIndex;

  const MainScreenState({this.selectedIndex = 0});
}
