// lib/features/exams/presentation/cubit/student_exam_results_cubit.dart

import 'package:bloc/bloc.dart';
import 'package:faculity_app2/features/exams/domain/repositories/exams_repository.dart';
import 'package:faculity_app2/features/exams/presentation/cubit/student_exam_results_state.dart';

class StudentExamResultsCubit extends Cubit<StudentExamResultsState> {
  final ExamRepository examsRepository;
  StudentExamResultsCubit({required this.examsRepository})
    : super(StudentExamResultsInitial());

  // This function now correctly reflects fetching results for a specific student
  Future<void> fetchStudentResults({required int studentId}) async {
    try {
      emit(StudentExamResultsLoading());
      // Assuming getStudentsForExam fetches results. The name might need clarification.
      // The logic here should align with a repository method that gets results for a student.
      // For now, we'll imagine it's `getStudentResults(studentId)`.
      // final resultsOrFailure = await examsRepository.getStudentResults(studentId);
      final resultsOrFailure = await examsRepository.getStudentsForExam(
        studentId,
      );

      resultsOrFailure.fold(
        (failure) => emit(StudentExamResultsFailure(failure.toString())),
        (results) => emit(StudentExamResultsSuccess(results)),
      );
    } on Exception catch (e) {
      emit(
        StudentExamResultsFailure(e.toString().replaceAll('Exception: ', '')),
      );
    }
  }
}
