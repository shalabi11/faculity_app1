// lib/features/auth/data/datasources/auth_remote_data_source.dart

import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:faculity_app2/core/errors/exceptions.dart';
import 'package:faculity_app2/core/utils/constant.dart';
import 'package:faculity_app2/features/auth/domain/entities/user.dart';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';

abstract class AuthRemoteDataSource {
  Future<UserModel> login({required Map<String, dynamic> data});
  Future<void> register({required Map<String, dynamic> data});
  Future<void> logout();
  Future<User> getUserProfile();
}

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  final Dio dio;
  // --- ✨ التعديل الأول: تغيير نوع المتغير ---
  final SharedPreferences sharedPreferences;

  AuthRemoteDataSourceImpl({
    required this.dio,
    required this.sharedPreferences,
  });

  @override
  Future<UserModel> login({required Map<String, dynamic> data}) async {
    try {
      final response = await dio.post('$baseUrl/api/login', data: data);

      if (response.statusCode == 200) {
        final userModel = UserModel.fromJson(response.data);
        if (userModel.token != null) {
          // --- ✨ التعديل الثاني: الحفظ في SharedPreferences ---
          await sharedPreferences.setString('auth_token', userModel.token!);

          // حفظ بيانات المستخدم كاملة كـ JSON String
          final userJson = jsonEncode({
            'id': userModel.id,
            'name': userModel.name,
            'email': userModel.email,
            'role': userModel.role,
            'year': userModel.year,
            'group': userModel.section, // اسم الحقل في API هو group
          });
          await sharedPreferences.setString('user_data', userJson);
        }
        return userModel;
      } else {
        throw ServerException(message: 'خطأ غير متوقع');
      }
    } on DioException catch (e) {
      handleDioException(e);
      throw ServerException(message: 'خطأ في الشبكة');
    }
  }

  @override
  Future<void> register({required Map<String, dynamic> data}) async {
    try {
      await dio.post(
        '$baseUrl/api/register',
        data: data,
        options: Options(headers: {'Accept': 'application/json'}),
      );
    } on DioException catch (e) {
      handleDioException(e);
    }
  }

  @override
  Future<void> logout() async {
    try {
      final token = sharedPreferences.getString('auth_token');
      if (token == null) {
        // إذا لم يكن هناك توكن، فالمستخدم قد خرج بالفعل
        await _clearUserData();
        return;
      }

      await dio.post(
        '$baseUrl/api/logout',
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );
    } on DioException catch (e) {
      // تجاهل أخطاء الشبكة عند تسجيل الخروج
    } finally {
      // --- ✨ التعديل الثالث: حذف البيانات من SharedPreferences ---
      await _clearUserData();
    }
  }

  // دالة مساعدة لحذف بيانات المستخدم
  Future<void> _clearUserData() async {
    await sharedPreferences.remove('auth_token');
    await sharedPreferences.remove('user_data');
  }

  @override
  Future<UserModel> getUserProfile() async {
    // --- ✨ التعديل الرابع: القراءة من SharedPreferences ---
    final token = sharedPreferences.getString('auth_token');
    final userDataString = sharedPreferences.getString('user_data');

    if (token == null || userDataString == null) {
      throw ServerException(message: 'No token or user data found');
    }

    final userData = jsonDecode(userDataString) as Map<String, dynamic>;
    // بناء UserModel من البيانات المحفوظة
    return UserModel(
      id: userData['id'],
      name: userData['name'],
      email: userData['email'],
      role: userData['role'],
      token: token,
      year: userData['year'],
      section: userData['group'],
    );
  }
}

// --- ✨ دالة معالجة الأخطاء بعد التعديل النهائي ✨ ---
void handleDioException(DioException e) {
  if (e.type == DioExceptionType.connectionError ||
      e.type == DioExceptionType.unknown ||
      e.type == DioExceptionType.badCertificate) {
    if (e.message != null && e.message!.contains('HandshakeException')) {
      throw ServerException(
        message:
            'خطأ في شهادة الأمان (SSL). تأكد من أن الخادم لديه شهادة صالحة.',
      );
    }
    throw ServerException(message: 'لا يوجد اتصال بالإنترنت أو الخادم متوقف.');
  }

  switch (e.type) {
    case DioExceptionType.badResponse:
      // ✨ --- تم إضافة الحالة 409 هنا --- ✨
      if (e.response?.statusCode == 409) {
        // الخادم يرسل رسالة الخطأ مباشرة في 'message'
        final message = e.response?.data['message'] ?? 'بيانات مكررة.';
        throw ServerException(message: message);
      }
      switch (e.response?.statusCode) {
        case 401:
          throw ServerException(message: 'بيانات الدخول غير صحيحة.');
        case 422:
          final errors = e.response?.data['errors'] as Map<String, dynamic>?;
          if (errors != null && errors.isNotEmpty) {
            throw ServerException(message: errors.values.first[0]);
          }
          throw ServerException(message: 'البيانات المدخلة غير صحيحة.');
        case 500:
          throw ServerException(
            message: 'حدث خطأ في الخادم، يرجى المحاولة مرة أخرى لاحقًا.',
          );
        default:
          throw ServerException(
            message: 'حدث خطأ غير متوقع: ${e.response?.statusCode}',
          );
      }
    case DioExceptionType.connectionTimeout:
    case DioExceptionType.sendTimeout:
    case DioExceptionType.receiveTimeout:
      throw ServerException(
        message: 'انتهت مهلة الاتصال، يرجى التحقق من شبكة الإنترنت.',
      );
    default:
      throw ServerException(message: 'تم إلغاء الطلب.');
  }
}
